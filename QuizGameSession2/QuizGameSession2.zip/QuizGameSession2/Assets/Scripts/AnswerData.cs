﻿[System.Serializable]
public class AnswerData
{
	public string answerText;
	public bool isCorrect;
}

